<?php
header("Location: /xvwa/");
?>